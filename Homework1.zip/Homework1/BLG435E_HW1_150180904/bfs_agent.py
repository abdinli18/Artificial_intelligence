import time
import random
from copy import deepcopy
from agent import Agent

#  use whichever data structure you like, or create a custom one
import queue
import heapq
from collections import deque

"""
  you may use the following Node class
  modify it if needed, or create your own
"""


class Node():
    def __init__(self, parent_node, level_matrix, player_row, player_column, depth, chosen_dir):
        self.parent_node = parent_node
        self.level_matrix = level_matrix
        self.player_row = player_row
        self.player_col = player_column
        self.depth = depth
        self.chosen_dir = chosen_dir
        self.howToCome = ""


class BFSAgent(Agent):

    def __init__(self):
        super().__init__()



    def solve(self, level_matrix, goal, player_row, player_column):
        super().solve(level_matrix, goal, player_row, player_column)
        move_sequence = []

        """
            YOUR CODE STARTS HERE
            fill move_sequence list with directions chars
        """

        find =False

        def isValidIndex(vis,row,column):
            if(row<0 or column<0 or row>=len(level_matrix) or column>=len(level_matrix[0])):
                return False
            
            if(vis[row][column]==True):
                return False
            
            if(level_matrix[row][column]=='W'):
                return False
            
            return True

        def isValidIndexTree(row,column):
            if(row<0 or column<0 or row>=len(level_matrix) or column>=len(level_matrix[0])):
                return False
            
            
            if(level_matrix[row][column]=='W'):
                return False
            
            return True
        
        
        '''The only difference between grapgh and tree search code in BFS is visited matrix. It is used in graph search so that 
        already visited nodes will not be visited again. But its impact is big. BFS becomes too slow'''
        #visited node tut
        # Declare the visited array
        vis = [[ False for i in range(len(level_matrix[0]))] for i in range(len(level_matrix))]
        #graph search
        my_queue = queue.Queue()
        parentnode = Node(None,None,player_row,player_column,None,None)
        numGenerated_nodes = 0
        numExpanded_nodes = 0
        Maxnum_memory = 0
        my_queue.put(parentnode)

        numGenerated_nodes = numGenerated_nodes+1
        Maxnum_memory = my_queue.qsize()

        vis[player_row][player_column] = True
        player_x = 0
        player_y = 0
        while(not my_queue.empty() and find==False):
            if(Maxnum_memory<my_queue.qsize()):
                Maxnum_memory = my_queue.qsize()
            parentnode = my_queue.get()  
            player_x = parentnode.player_row
            player_y = parentnode.player_col
            if(parentnode.player_row==goal[0] and parentnode.player_col==goal[1]):
                #print('sonuc buldu')
                #print(parentnode.player_row,parentnode.player_col)
                #print(goal[0],goal[1])
                find=True
                break
            
            isExpand = False
            
            #if there is valid neighbor it is added to queue(FIFO)
            if(isValidIndex(vis,player_x-1,player_y)):
                #print(player_x-1,player_y,'U')
                childnode  = Node(parentnode,None,player_x-1,player_y,None,None)
                #parentnode = childnode
                isExpand = True
                my_queue.put(childnode)#adding queue
                numGenerated_nodes = numGenerated_nodes+1
                childnode.howToCome = "U"
                vis[player_x-1][player_y]=True#setting visited true

            if(isValidIndex(vis,player_x+1,player_y)):
                #print(player_x+1,player_y,'D')
                childnode  = Node(parentnode,None,player_x+1,player_y,None,None)
                #parentnode = childnode
                isExpand = True
                my_queue.put(childnode)
                numGenerated_nodes = numGenerated_nodes+1
                childnode.howToCome = "D"
                vis[player_x+1][player_y]=True

            if(isValidIndex(vis,player_x,player_y-1)):
                #print(player_x,player_y-1,'L')
                childnode  = Node(parentnode,None,player_x,player_y-1,None,None)
                #parentnode = childnode
                isExpand = True
                my_queue.put(childnode)
                numGenerated_nodes = numGenerated_nodes+1
                childnode.howToCome = "L"
                vis[player_x][player_y-1]=True

            if(isValidIndex(vis,player_x,player_y+1)):
                #print(player_x,player_y+1,'R')
                childnode  = Node(parentnode,None,player_x,player_y+1,None,None)
                #parentnode = childnode
                isExpand = True
                my_queue.put(childnode)
                numGenerated_nodes = numGenerated_nodes+1
                childnode.howToCome = "R"
                vis[player_x][player_y+1]=True
            
            if(isExpand):
                numExpanded_nodes = numExpanded_nodes+1

        while(parentnode.player_row!=player_row or parentnode.player_col!=player_column):
            move_sequence.append(parentnode.howToCome)
            parentnode = parentnode.parent_node

        move_sequence.reverse()
        self.generated_node_count = numGenerated_nodes
        self.expanded_node_count = numExpanded_nodes
        self.maximum_node_in_memory_count = Maxnum_memory
        #move_sequence = ['R','R','D','D','D','D','R','R','D','D','R']


        #tree search
        '''my_queue = queue.Queue()
        parentnode = Node(None,None,player_row,player_column,None,None)
        numGenerated_nodes = 0
        numExpanded_nodes = 0
        Maxnum_memory = 0
        my_queue.put(parentnode)

        numGenerated_nodes = numGenerated_nodes+1
        Maxnum_memory = my_queue.qsize()

        player_x = 0
        player_y = 0
        while(not my_queue.empty() and find==False):
            if(Maxnum_memory<my_queue.qsize()):
                Maxnum_memory = my_queue.qsize()
            #print('while giris')
            parentnode = my_queue.get()  
            player_x = parentnode.player_row
            player_y = parentnode.player_col
            #print(player_x,player_y)
            if(parentnode.player_row==goal[0] and parentnode.player_col==goal[1]):
                #print('sonuc buldu')
                #print(parentnode.player_row,parentnode.player_col)
                #print(goal[0],goal[1])
                find=True
                break
            
            isExpand = False
            

            if(isValidIndexTree(player_x-1,player_y)):
                #print(player_x-1,player_y,'U')
                childnode  = Node(parentnode,None,player_x-1,player_y,None,None)
                #parentnode = childnode
                isExpand = True
                my_queue.put(childnode)
                numGenerated_nodes = numGenerated_nodes+1
                childnode.howToCome = "U"

            if(isValidIndexTree(player_x+1,player_y)):
                #print(player_x+1,player_y,'D')
                childnode  = Node(parentnode,None,player_x+1,player_y,None,None)
                #parentnode = childnode
                isExpand = True
                my_queue.put(childnode)
                numGenerated_nodes = numGenerated_nodes+1
                childnode.howToCome = "D"

            if(isValidIndexTree(player_x,player_y-1)):
                #print(player_x,player_y-1,'L')
                childnode  = Node(parentnode,None,player_x,player_y-1,None,None)
                #parentnode = childnode
                isExpand = True
                my_queue.put(childnode)
                numGenerated_nodes = numGenerated_nodes+1
                childnode.howToCome = "L"

            if(isValidIndexTree(player_x,player_y+1)):
                #print(player_x,player_y+1,'R')
                childnode  = Node(parentnode,None,player_x,player_y+1,None,None)
                #parentnode = childnode
                isExpand = True
                my_queue.put(childnode)
                numGenerated_nodes = numGenerated_nodes+1
                childnode.howToCome = "R"
            
            if(isExpand):
                numExpanded_nodes = numExpanded_nodes+1

        #tree search
        while(parentnode.player_row!=player_row or parentnode.player_col!=player_column):
            move_sequence.append(parentnode.howToCome)
            parentnode = parentnode.parent_node

        move_sequence.reverse()
        self.generated_node_count = numGenerated_nodes
        self.expanded_node_count = numExpanded_nodes
        self.maximum_node_in_memory_count = Maxnum_memory
        #move_sequence = ['R','R','D','D','D','D','R','R','D','D','R']'''


        """
            YOUR CODE ENDS HERE
            return move_sequence
        """
        return move_sequence
    
