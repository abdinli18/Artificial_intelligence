import time
import random
from copy import deepcopy
from agent import Agent

#  use whichever data structure you like, or create a custom one
import queue
import heapq
from collections import deque

"""
  you may use the following Node class
  modify it if needed, or create your own
"""


class Node():

    def __init__(self, parent_node, level_matrix, player_row, player_column, depth, chosen_dir):
        self.parent_node = parent_node
        self.level_matrix = level_matrix
        self.player_row = player_row
        self.player_col = player_column
        self.depth = depth
        self.chosen_dir = chosen_dir
        howToCome = ""


class DFSAgent(Agent):

    def __init__(self):
        super().__init__()

    def solve(self, level_matrix, goal, player_row, player_column):
        super().solve(level_matrix, goal, player_row, player_column)
        move_sequence = []

        """
            YOUR CODE STARTS HERE
            fill move_sequence list with directions chars
        """
        def isValidIndex(vis,row,column):
            if(row<0 or column<0 or row>=len(level_matrix) or column>=len(level_matrix[0])):
                return False
            
            if(vis[row][column]==True):
                return False
            
            if(level_matrix[row][column]=='W'):
                return False
            
            return True
        

        def isValidIndexTree(row,column):
            if(row<0 or column<0 or row>=len(level_matrix) or column>=len(level_matrix[0])):
                return False
            
            
            if(level_matrix[row][column]=='W'):
                return False
            
            return True        


        '''The only difference between grapgh and tree search code in DFS is visited matrix. It is used in graph search so that 
        already visited nodes will not be visited again. But its impact is too big. DFS does not end. I explained why that occurs in report'''
        #store if cell is visited or not visited
        vis = [[ False for i in range(len(level_matrix[0]))] for i in range(len(level_matrix))]
        #create first node
        numGenerated_nodes = 0
        numExpanded_nodes = 0
        Maxnum_memory = 0
        num_mem =  0
        found = False
        parentnode = Node(None,level_matrix,player_row,player_column,None,None)
        vis[player_row][player_column] = True
        def dfsSearch(row, column, funcparent):
            nonlocal numExpanded_nodes
            nonlocal numGenerated_nodes
            nonlocal Maxnum_memory
            nonlocal num_mem
            nonlocal found
            numGenerated_nodes = numGenerated_nodes+1
            num_mem = num_mem+1
            if(Maxnum_memory<num_mem):
                Maxnum_memory = num_mem
                        
            #print(row, column, funcparent)
            isExpaned = False
            if(isValidIndex(vis,row-1,column) and not found):
                isExpaned = True
                childnode = Node(funcparent,level_matrix,row-1,column,None,None)
                vis[row-1][column] = True
                childnode.howToCome = 'U'
                dfsSearch(row-1,column,childnode)
            
            if(isValidIndex(vis,row+1,column) and not found):
                isExpaned = True
                childnode = Node(funcparent,level_matrix,row+1,column,None,None)
                vis[row+1][column] = True
                childnode.howToCome = 'D'
                dfsSearch(row+1,column,childnode)

            if(isValidIndex(vis,row,column-1)and not found):
                isExpaned = True
                childnode = Node(funcparent,level_matrix,row,column-1,None,None)
                vis[row][column-1] = True
                childnode.howToCome = 'L'
                dfsSearch(row,column-1,childnode)
            
            if(isValidIndex(vis,row,column+1)and not found):
                isExpaned = True
                childnode = Node(funcparent,level_matrix,row,column+1,None,None)
                vis[row][column+1] = True
                childnode.howToCome = 'R'
                dfsSearch(row,column+1,childnode)
            
            if(isExpaned):
                numExpanded_nodes = numExpanded_nodes+1
            if(goal[0] == row and goal[1]==column):
                nonlocal parentnode
                parentnode = funcparent
                found = True
            num_mem = num_mem-1
            return

        dfsSearch(player_row,player_column,parentnode)
        #print(parentnode.player_row, parentnode.player_col)
        while(parentnode.player_row!=player_row or parentnode.player_col!=player_column):
            move_sequence.append(parentnode.howToCome)
            parentnode = parentnode.parent_node

        move_sequence.reverse()

        self.generated_node_count = numGenerated_nodes
        self.expanded_node_count = numExpanded_nodes
        self.maximum_node_in_memory_count = Maxnum_memory
        #move_sequence = ['R','R','D','D','D','D','R','R','D','D','R']

        
        #print(parentnode.player_row, parentnode.player_col)

        #create first node
        '''numGenerated_nodes = 0
        numExpanded_nodes = 0
        Maxnum_memory = 0
        num_mem =  0
        found = False
        parentnode = Node(None,level_matrix,player_row,player_column,None,None)
        def dfsSearch(row, column, funcparent):
            nonlocal numExpanded_nodes
            nonlocal numGenerated_nodes
            nonlocal Maxnum_memory
            nonlocal num_mem
            nonlocal found
            numGenerated_nodes = numGenerated_nodes+1
            num_mem = num_mem+1
            if(Maxnum_memory<num_mem):
                Maxnum_memory = num_mem
                        
            #print(row, column, funcparent)
            isExpaned = False
            if(isValidIndexTree(row-1,column) and not found):
                isExpaned = True
                childnode = Node(funcparent,level_matrix,row-1,column,None,None)
                childnode.howToCome = 'U'
                dfsSearch(row-1,column,childnode)
            
            if(isValidIndexTree(row+1,column) and not found):
                isExpaned = True
                childnode = Node(funcparent,level_matrix,row+1,column,None,None)
                childnode.howToCome = 'D'
                dfsSearch(row+1,column,childnode)

            if(isValidIndexTree(row,column-1)and not found):
                isExpaned = True
                childnode = Node(funcparent,level_matrix,row,column-1,None,None)
                childnode.howToCome = 'L'
                dfsSearch(row,column-1,childnode)
            
            if(isValidIndexTree(row,column+1)and not found):
                isExpaned = True
                childnode = Node(funcparent,level_matrix,row,column+1,None,None)
                childnode.howToCome = 'R'
                dfsSearch(row,column+1,childnode)
            
            if(isExpaned):
                numExpanded_nodes = numExpanded_nodes+1
            if(goal[0] == row and goal[1]==column):
                nonlocal parentnode
                parentnode = funcparent
                found = True
            num_mem = num_mem-1
            return

        dfsSearch(player_row,player_column,parentnode)
        #print(parentnode.player_row, parentnode.player_col)
        while(parentnode.player_row!=player_row or parentnode.player_col!=player_column):
            move_sequence.append(parentnode.howToCome)
            parentnode = parentnode.parent_node

        move_sequence.reverse()

        self.generated_node_count = numGenerated_nodes
        self.expanded_node_count = numExpanded_nodes
        self.maximum_node_in_memory_count = Maxnum_memory'''

        """
            YOUR CODE ENDS HERE
            return move_sequence
        """
        return move_sequence