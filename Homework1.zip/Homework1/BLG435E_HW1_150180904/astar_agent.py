import time
import random
from copy import deepcopy
from agent import Agent
import math

#  use whichever data structure you like, or create a custom one
import queue
import heapq
from collections import deque

"""
  you may use the following Node class
  modify it if needed, or create your own
"""


class Node():

    def __init__(self, parent_node, level_matrix, player_row, player_column, depth, chosen_dir, h_value):
        self.parent_node = parent_node
        self.level_matrix = level_matrix
        self.player_row = player_row
        self.player_col = player_column
        self.depth = depth
        self.chosen_dir = chosen_dir
        self.h = h_value

    def __lt__(self, other:"Node"):
        return self.depth + self.h < other.depth + other.h

        """
            There are different strategies you can choose for
        tie breaking, that is, which node to choose when two
        nodes have equal f (g+h) values. Some of these are:

        1- Choose the node with lower h value, implying that you
        trust your heuristic more than g.

        2- Choose the node with lower g value, implying that you
        do not trust your heuristic function that much.

        3- Choose the node which is put into the
        queue earlier/later

        4- Use a secondary heuristic function to compare two 
        nodes when they have equal f value

        5- Select one of the nodes randomly. Not good for this
        assignment, but if you are making a game this also has
        an effect that makes your agent follow different routes
        each time it runs (if there are more than 1 shortest path
        to goal)

        ...
        ...
        ... 
        """


class PriorityQueue:
    def __init__(self):
        self.elements = []

    def empty(self):
        return len(self.elements) == 0

    def put(self, item, priority):
        #heapq.heappush(self.elements, (priority, item))
        heapq.heappush(self.elements,  item)

    def get(self):
        return heapq.heappop(self.elements)


class AStarAgent(Agent):

    def __init__(self):
        super().__init__()

    def solve(self, level_matrix, goal, player_row, player_column):
        super().solve(level_matrix, goal, player_row, player_column)
        move_sequence = []

        """
            YOUR CODE STARTS HERE
            fill move_sequence list with directions chars
        """
        find =False

        def isValidIndex(vis,row,column):
            if(row<0 or column<0 or row>=len(level_matrix) or column>=len(level_matrix[0])):
                return False
            
            if(vis[row][column]==True):
                return False
            
            if(level_matrix[row][column]=='W'):
                return False
            
            return True
        
        def EuclideanDist(row1,col1,row2,col2):
            return math.sqrt((row2-row1)**2 + (col2-col1)**2)

        '''grapgh search using real distance(manhattan distance)'''
        vis = [[ False for i in range(len(level_matrix[0]))] for i in range(len(level_matrix))]#visited matrix
        my_queue = PriorityQueue()
        a = Agent.real_distance(self,player_row,player_column,goal[0],goal[1])
        parentnode = Node(None,None,player_row,player_column,0,None,a)
        startPosition = parentnode
        numGenerated_nodes = 0
        numExpanded_nodes = 0
        Maxnum_memory = 0
        my_queue.put(parentnode,0)
        numGenerated_nodes = numGenerated_nodes+1
        Maxnum_memory = len(my_queue.elements)
        vis[player_row][player_column]=True
        while(not my_queue.empty() and find==False):
            if(Maxnum_memory<len(my_queue.elements)):
                Maxnum_memory = len(my_queue.elements)
            parentnode = my_queue.get()
            player_x = parentnode.player_row
            player_y = parentnode.player_col

            if(parentnode.player_row==goal[0] and parentnode.player_col==goal[1]):
                #print('sonuc buldu')
                #print(parentnode.player_row,parentnode.player_col)
                #print(goal[0],goal[1])
                find=True
                break
            isExpanded = False
            #adds if any of neighbors are valid
            if(isValidIndex(vis,player_x-1,player_y)):
                #print(player_x-1,player_y,'U')
                g_value = parentnode.depth+1#g_value is parents depth +1
                h_value = Agent.real_distance(self,player_x-1,player_y,goal[0],goal[1])#calculate real distance
                childnode  = Node(parentnode,None,player_x-1,player_y,g_value,"U", h_value)
                isExpanded=True
                my_queue.put(childnode,g_value+h_value)#putting into queue
                numGenerated_nodes = numGenerated_nodes+1
                vis[player_x-1][player_y]=True#setting the visited true

            if(isValidIndex(vis,player_x+1,player_y)):
                #print(player_x+1,player_y,'D')
                g_value = parentnode.depth+1
                h_value = Agent.real_distance(self,player_x+1,player_y,goal[0],goal[1])
                childnode  = Node(parentnode,None,player_x+1,player_y,g_value,"D", h_value)
                isExpanded=True
                my_queue.put(childnode,g_value+h_value)
                numGenerated_nodes = numGenerated_nodes+1
                vis[player_x+1][player_y]=True            

            if(isValidIndex(vis,player_x,player_y-1)):
                #print(player_x,player_y-1,'L')
                g_value = parentnode.depth+1
                h_value = Agent.real_distance(self,player_x,player_y-1,goal[0],goal[1])
                childnode  = Node(parentnode,None,player_x,player_y-1,g_value,"L", h_value)
                isExpanded=True
                my_queue.put(childnode,g_value+h_value)
                numGenerated_nodes = numGenerated_nodes+1
                vis[player_x][player_y-1]=True



            if(isValidIndex(vis,player_x,player_y+1)):
                #print(player_x,player_y+1,'R')
                g_value = parentnode.depth+1
                h_value = Agent.real_distance(self,player_x,player_y+1,goal[0],goal[1])
                childnode  = Node(parentnode,None,player_x,player_y+1,g_value,"R", h_value)
                isExpanded = True
                my_queue.put(childnode,g_value+h_value)
                numGenerated_nodes = numGenerated_nodes+1
                vis[player_x][player_y+1]=True

            if(isExpanded):
                numExpanded_nodes = numExpanded_nodes+1

        
        
        while(parentnode.player_row!=player_row or parentnode.player_col!=player_column):
            move_sequence.append(parentnode.chosen_dir)
            parentnode = parentnode.parent_node


        self.generated_node_count = numGenerated_nodes
        self.expanded_node_count = numExpanded_nodes
        self.maximum_node_in_memory_count = Maxnum_memory
        move_sequence.reverse()
        #move_sequence = ['R','R','D','D','D','D','R','R','D','D','R']

        '''grapgh search using euclidean distance'''
        '''vis = [[ False for i in range(len(level_matrix[0]))] for i in range(len(level_matrix))]
        my_queue = PriorityQueue()
        a = EuclideanDist(player_row,player_column,goal[0],goal[1])
        parentnode = Node(None,None,player_row,player_column,0,None,a)
        startPosition = parentnode
        numGenerated_nodes = 0
        numExpanded_nodes = 0
        Maxnum_memory = 0
        my_queue.put(parentnode,0)
        numGenerated_nodes = numGenerated_nodes+1
        Maxnum_memory = len(my_queue.elements)
        vis[player_row][player_column]=True
        while(not my_queue.empty() and find==False):
            if(Maxnum_memory<len(my_queue.elements)):
                Maxnum_memory = len(my_queue.elements)
            parentnode = my_queue.get()
            player_x = parentnode.player_row
            player_y = parentnode.player_col

            if(parentnode.player_row==goal[0] and parentnode.player_col==goal[1]):
                #print('sonuc buldu')
                #print(parentnode.player_row,parentnode.player_col)
                #print(goal[0],goal[1])
                find=True
                break
            isExpanded = False
            
            if(isValidIndex(vis,player_x-1,player_y)):
                #print(player_x-1,player_y,'U')
                g_value = parentnode.depth+1
                h_value = EuclideanDist(player_x-1,player_y,goal[0],goal[1])
                childnode  = Node(parentnode,None,player_x-1,player_y,g_value,"U", h_value)
                isExpanded=True
                my_queue.put(childnode,g_value+h_value)
                numGenerated_nodes = numGenerated_nodes+1
                vis[player_x-1][player_y]=True

            if(isValidIndex(vis,player_x+1,player_y)):
                #print(player_x+1,player_y,'D')
                g_value = parentnode.depth+1
                h_value = EuclideanDist(player_x+1,player_y,goal[0],goal[1])
                childnode  = Node(parentnode,None,player_x+1,player_y,g_value,"D", h_value)
                isExpanded=True
                my_queue.put(childnode,g_value+h_value)
                numGenerated_nodes = numGenerated_nodes+1
                vis[player_x+1][player_y]=True            

            if(isValidIndex(vis,player_x,player_y-1)):
                #print(player_x,player_y-1,'L')
                g_value = parentnode.depth+1
                h_value = EuclideanDist(player_x,player_y-1,goal[0],goal[1])
                childnode  = Node(parentnode,None,player_x,player_y-1,g_value,"L", h_value)
                isExpanded=True
                my_queue.put(childnode,g_value+h_value)
                numGenerated_nodes = numGenerated_nodes+1
                vis[player_x][player_y-1]=True



            if(isValidIndex(vis,player_x,player_y+1)):
                #print(player_x,player_y+1,'R')
                g_value = parentnode.depth+1
                h_value = EuclideanDist(player_x,player_y+1,goal[0],goal[1])
                childnode  = Node(parentnode,None,player_x,player_y+1,g_value,"R", h_value)
                isExpanded=True
                my_queue.put(childnode,g_value+h_value)
                numGenerated_nodes = numGenerated_nodes+1
                vis[player_x][player_y+1]=True

            if(isExpanded):
                numExpanded_nodes = numExpanded_nodes+1


        
        
        while(parentnode.player_row!=player_row or parentnode.player_col!=player_column):
            move_sequence.append(parentnode.chosen_dir)
            parentnode = parentnode.parent_node


        self.generated_node_count = numGenerated_nodes
        self.expanded_node_count = numExpanded_nodes
        self.maximum_node_in_memory_count = Maxnum_memory
        move_sequence.reverse()'''

        """
            YOUR CODE ENDS HERE
            return move_sequence
        """
        return move_sequence