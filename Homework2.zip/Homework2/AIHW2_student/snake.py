from gym.core import RewardWrapper
import pygame
from snake_environment import *
from snake_renderer import *
import numpy as np


class CustomSnake(Snake):
    def __init__(self,
                 human=False,
                 mode=SnakeMode.NOTAIL,
                 render=True,
                 game_window_name="Snake Variants - 5000 in 1"):
        super(CustomSnake, self).__init__(human, mode, Renderer(game_window_name) if render else None)

        """
        DEFINE YOUR OBSERVATION SPACE DIMENSIONS HERE FOR EACH MODE.
        JUST CHANGING THE "obs_space_dim" VARIABLE SHOULD BE ENOUGH
        """
        if mode == SnakeMode.NOTAIL:
            obs_space_dim = 5
            self.observation_space = spaces.Box(0, obs_space_dim, shape=(obs_space_dim,))
        elif mode == SnakeMode.CLASSIC:
            obs_space_dim = 5
            self.observation_space = spaces.Box(0, obs_space_dim, shape=(obs_space_dim,))
        elif mode == SnakeMode.TRON:
            obs_space_dim = 5
            self.observation_space = spaces.Box(0, obs_space_dim, shape=(obs_space_dim,))

    def get_state(self):
        """
        Define your state representation here
        :return:
        """
        #print(self)
        head = self.snake_pos
        #print(self.hit_the_wall)
        if self.game_mode == SnakeMode.NOTAIL:
            #near_apple =0
            #if((self.snake_pos[0]>= self.apple_pos[0]-2 and self.snake_pos[0]<= self.apple_pos[0]+2) and (self.snake_pos[1]>= self.apple_pos[1]-2 and self.snake_pos[1]<= self.apple_pos[1]+2)):
            #    near_apple = 1
            state = [self.snake_pos[0],self.snake_pos[1], convert_direction_to_action(self.snake_direction), self.apple_pos[0],self.apple_pos[1]]
            return state
            #raise NotImplementedError("Implement your state representation for Snake-NoTail")
        elif self.game_mode == SnakeMode.CLASSIC:
            state = [self.snake_pos[0],self.snake_pos[1], convert_direction_to_action(self.snake_direction), self.apple_pos[0],self.apple_pos[1]]
            return state
            #raise NotImplementedError("Implement your state representation for Snake-Classic")
        elif self.game_mode == SnakeMode.TRON:
            state = [self.snake_pos[0],self.snake_pos[1], convert_direction_to_action(self.snake_direction), self.apple_pos[0],self.apple_pos[1]]
            return state            
            #raise NotImplementedError("Implement your state representation for Snake-Tron")
        else:
            raise ModuleNotFoundError("This mode is currently not supported. Please refer to the manual")

    def get_reward(self):
        """
        Define your reward calculations here
        :return:
            A value between (-1, 1)
        """

        def euclidean_distance(apple_pos, snake_pos):
            return np.sqrt((apple_pos[0]-snake_pos[0])**2 + (apple_pos[1]-snake_pos[1])**2)


        if self.game_mode == SnakeMode.NOTAIL:
            if(self.hit_the_wall):
                return -1
            elif(self.ate_apple):
                #print("ate is done!!!")
                return 1
            elif((self.snake_pos[0]>= self.apple_pos[0]-1 and self.snake_pos[0]<= self.apple_pos[0]+1) and (self.snake_pos[1]>= self.apple_pos[1]-1 and self.snake_pos[1]<= self.apple_pos[1]+1)):
                #print("near apple")
                return 0.3
            else:
                return 0
            raise NotImplementedError("Implement your reward function for Snake-NoTail")
        elif self.game_mode == SnakeMode.CLASSIC:
            if(self.hit_the_wall):
                return -1
            elif(self.ate_apple):
                #print("ate is done!!!")
                return 1
            else:
                #isTrueWay = 0
                #reward=0
                #print(self.snake_pos)
                #print(self.apple_pos)
                #print(np.array(self.apple_pos)-np.array(self.snake_pos), "this diff")
                distance_diff = np.array(self.apple_pos)-np.array(self.snake_pos)
                if(distance_diff[1]>0 and self.snake_direction=='R'):
                    return 1/(euclidean_distance(self.apple_pos,self.snake_pos)+1)
                elif(distance_diff[1]<0 and self.snake_direction=='L'):
                    return 1/(euclidean_distance(self.apple_pos,self.snake_pos)+1)
                elif(distance_diff[1]==0 and (self.snake_direction=='L' or self.snake_direction=='R')):
                    return -1/(euclidean_distance(self.apple_pos,self.snake_pos)+1)
                
                if(distance_diff[0]>0 and self.snake_direction=='D'):
                    return 1/(euclidean_distance(self.apple_pos,self.snake_pos)+1)
                elif(distance_diff[0]<0 and self.snake_direction=='U'):
                    return 1/(euclidean_distance(self.apple_pos,self.snake_pos)+1)
                elif(distance_diff[0]==0 and (self.snake_direction=='D' or self.snake_direction=='U')):
                    return -1/(euclidean_distance(self.apple_pos,self.snake_pos)+1)
                

                return 0
            #raise NotImplementedError("Implement your reward function for Snake-Classic")
        elif self.game_mode == SnakeMode.TRON:
            if(self.hit_the_wall):
                return -1
            elif(self.ate_apple):
                #print("ate is done!!!")
                return 1
            else:
                return 0.1/(euclidean_distance(self.apple_pos, self.snake_pos)+0.5)+0.2
            #raise NotImplementedError("Implement your reward function for Snake-Tron")
        else:
            raise ModuleNotFoundError("This mode is currently not supported. Please refer to the manual")
